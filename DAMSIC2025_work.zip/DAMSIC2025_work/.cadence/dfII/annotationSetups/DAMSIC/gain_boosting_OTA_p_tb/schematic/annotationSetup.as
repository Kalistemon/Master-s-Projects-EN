Design:DAMSIC gain_boosting_OTA_p_tb schematic
annInstExceptionList:gpdk045 pmos1v *,gpdk045 nmos1v *

Instance:analogLib vsin *
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vo
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:va
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:freq

Instance:gpdk045 pmos1v *
cdsName:
instName schematic true true
cdsTerm:
B current annotate?:true
B current balloon?:true
B current displayType:DC
B display mode:voltage
B netName annotate?:true
B netName balloon?:true
B netName displayType:schematic
B none annotate?:true
B none balloon?:true
B pinName annotate?:true
B pinName balloon?:true
B voltage annotate?:true
B voltage balloon?:true
B voltage displayType:DC
B voltageCurrent annotate?:true
B voltageCurrent balloon?:true
B voltageCurrent displayType:DC
D current annotate?:true
D current balloon?:true
D current displayType:DC
D display mode:voltage
D netName annotate?:true
D netName balloon?:true
D netName displayType:schematic
D none annotate?:true
D none balloon?:true
D pinName annotate?:true
D pinName balloon?:true
D voltage annotate?:true
D voltage balloon?:true
D voltage displayType:DC
D voltageCurrent annotate?:true
D voltageCurrent balloon?:true
D voltageCurrent displayType:DC
G current annotate?:true
G current balloon?:true
G current displayType:DC
G display mode:voltage
G netName annotate?:true
G netName balloon?:true
G netName displayType:schematic
G none annotate?:true
G none balloon?:true
G pinName annotate?:true
G pinName balloon?:true
G voltage annotate?:true
G voltage balloon?:true
G voltage displayType:DC
G voltageCurrent annotate?:true
G voltageCurrent balloon?:true
G voltageCurrent displayType:DC
S current annotate?:true
S current balloon?:true
S current displayType:DC
S display mode:voltage
S netName annotate?:true
S netName balloon?:true
S netName displayType:schematic
S none annotate?:true
S none balloon?:true
S pinName annotate?:true
S pinName balloon?:true
S voltage annotate?:true
S voltage balloon?:true
S voltage displayType:DC
S voltageCurrent annotate?:true
S voltageCurrent balloon?:true
S voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:vto
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:id
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:nil nil nil t nil
1 parameter label:;model
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:kp
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:vgs
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:nil nil nil t nil
2 parameter label:w
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:gamma
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:vds
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:nil nil nil t nil
3 parameter label:l
4 dbLabel :true
4 display mode:opPoint
4 model annotate?:true
4 model balloon?:true
4 model label:
4 none annotate?:true
4 none balloon?:true
4 opPoint annotate?:true
4 opPoint balloon?:true
4 opPoint displayType:DC
4 opPoint label:gm
4 parameter annotate?:true
4 parameter balloon?:true
4 parameter displayType:nil nil nil t nil
4 parameter label:m
5 dbLabel :true
5 display mode:opPoint
5 model annotate?:true
5 model balloon?:true
5 model label:
5 none annotate?:true
5 none balloon?:true
5 opPoint annotate?:true
5 opPoint balloon?:true
5 opPoint displayType:DC
5 opPoint label:region
5 parameter annotate?:true
5 parameter balloon?:true
5 parameter displayType:nil nil nil t nil
5 parameter label:

Instance:gpdk045 nmos1v *
cdsName:
instName schematic true true
cdsTerm:
B current annotate?:true
B current balloon?:true
B current displayType:DC
B display mode:voltage
B netName annotate?:true
B netName balloon?:true
B netName displayType:schematic
B none annotate?:true
B none balloon?:true
B pinName annotate?:true
B pinName balloon?:true
B voltage annotate?:true
B voltage balloon?:true
B voltage displayType:DC
B voltageCurrent annotate?:true
B voltageCurrent balloon?:true
B voltageCurrent displayType:DC
D current annotate?:true
D current balloon?:true
D current displayType:DC
D display mode:voltage
D netName annotate?:true
D netName balloon?:true
D netName displayType:schematic
D none annotate?:true
D none balloon?:true
D pinName annotate?:true
D pinName balloon?:true
D voltage annotate?:true
D voltage balloon?:true
D voltage displayType:DC
D voltageCurrent annotate?:true
D voltageCurrent balloon?:true
D voltageCurrent displayType:DC
G current annotate?:true
G current balloon?:true
G current displayType:DC
G display mode:voltage
G netName annotate?:true
G netName balloon?:true
G netName displayType:schematic
G none annotate?:true
G none balloon?:true
G pinName annotate?:true
G pinName balloon?:true
G voltage annotate?:true
G voltage balloon?:true
G voltage displayType:DC
G voltageCurrent annotate?:true
G voltageCurrent balloon?:true
G voltageCurrent displayType:DC
S current annotate?:true
S current balloon?:true
S current displayType:DC
S display mode:voltage
S netName annotate?:true
S netName balloon?:true
S netName displayType:schematic
S none annotate?:true
S none balloon?:true
S pinName annotate?:true
S pinName balloon?:true
S voltage annotate?:true
S voltage balloon?:true
S voltage displayType:DC
S voltageCurrent annotate?:true
S voltageCurrent balloon?:true
S voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:vto
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:id
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:nil nil nil t nil
1 parameter label:;model
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:kp
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:vgs
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:nil nil nil t nil
2 parameter label:w
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:gamma
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:vds
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:nil nil nil t nil
3 parameter label:l
4 dbLabel :true
4 display mode:opPoint
4 model annotate?:true
4 model balloon?:true
4 model label:
4 none annotate?:true
4 none balloon?:true
4 opPoint annotate?:true
4 opPoint balloon?:true
4 opPoint displayType:DC
4 opPoint label:gm
4 parameter annotate?:true
4 parameter balloon?:true
4 parameter displayType:nil nil nil t nil
4 parameter label:m
5 dbLabel :true
5 display mode:opPoint
5 model annotate?:true
5 model balloon?:true
5 model label:
5 none annotate?:true
5 none balloon?:true
5 opPoint annotate?:true
5 opPoint balloon?:true
5 opPoint displayType:DC
5 opPoint label:region
5 parameter annotate?:true
5 parameter balloon?:true
5 parameter displayType:nil nil nil t nil
5 parameter label:

Instance:analogLib ideal_balun I7
cdsName:
instName schematic true true
cdsTerm:
c current annotate?:true
c current balloon?:true
c current displayType:DC
c display mode:none
c netName annotate?:true
c netName balloon?:true
c netName displayType:schematic
c none annotate?:true
c none balloon?:true
c pinName annotate?:true
c pinName balloon?:true
c voltage annotate?:true
c voltage balloon?:true
c voltage displayType:DC
c voltageCurrent annotate?:true
c voltageCurrent balloon?:true
c voltageCurrent displayType:DC
d current annotate?:true
d current balloon?:true
d current displayType:DC
d display mode:none
d netName annotate?:true
d netName balloon?:true
d netName displayType:schematic
d none annotate?:true
d none balloon?:true
d pinName annotate?:true
d pinName balloon?:true
d voltage annotate?:true
d voltage balloon?:true
d voltage displayType:DC
d voltageCurrent annotate?:true
d voltageCurrent balloon?:true
d voltageCurrent displayType:DC
n current annotate?:true
n current balloon?:true
n current displayType:DC
n display mode:none
n netName annotate?:true
n netName balloon?:true
n netName displayType:schematic
n none annotate?:true
n none balloon?:true
n pinName annotate?:true
n pinName balloon?:true
n voltage annotate?:true
n voltage balloon?:true
n voltage displayType:DC
n voltageCurrent annotate?:true
n voltageCurrent balloon?:true
n voltageCurrent displayType:DC
p current annotate?:true
p current balloon?:true
p current displayType:DC
p display mode:none
p netName annotate?:true
p netName balloon?:true
p netName displayType:schematic
p none annotate?:true
p none balloon?:true
p pinName annotate?:true
p pinName balloon?:true
p voltage annotate?:true
p voltage balloon?:true
p voltage displayType:DC
p voltageCurrent annotate?:true
p voltageCurrent balloon?:true
p voltageCurrent displayType:DC
cdsParam:

Instance:analogLib vdc Vb4
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:analogLib vdc Vb3
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:analogLib vdc Vb1
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:analogLib * *
cdsName:
instName schematic true true
cdsTerm:
 current annotate?:true
 current balloon?:true
 current displayType:DC
 display mode:none
 netName annotate?:true
 netName balloon?:true
 netName displayType:schematic
 none annotate?:true
 none balloon?:true
 pinName annotate?:true
 pinName balloon?:true
 voltage annotate?:true
 voltage balloon?:true
 voltage displayType:DC
 voltageCurrent annotate?:true
 voltageCurrent balloon?:true
 voltageCurrent displayType:DC
cdsParam:
 dbLabel :true
 display mode:opPoint
 model annotate?:true
 model balloon?:true
 model label:none
 none annotate?:true
 none balloon?:true
 none label:
 opPoint annotate?:true
 opPoint balloon?:true
 opPoint displayType:DC
 opPoint label:none
 parameter annotate?:true
 parameter balloon?:true
 parameter displayType:t nil nil nil nil
 parameter label:none

Instance:analogLib vdc Vb6
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:analogLib vdc Vdd
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:analogLib vsin V1
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vo
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:va
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:freq

Instance:analogLib vdc V0
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:analogLib vdc Vb5
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:analogLib vdc *
cdsName:
instName schematic true true
cdsTerm:
MINUS current annotate?:true
MINUS current balloon?:true
MINUS current displayType:DC
MINUS display mode:none
MINUS netName annotate?:true
MINUS netName balloon?:true
MINUS netName displayType:schematic
MINUS none annotate?:true
MINUS none balloon?:true
MINUS pinName annotate?:true
MINUS pinName balloon?:true
MINUS voltage annotate?:true
MINUS voltage balloon?:true
MINUS voltage displayType:DC
MINUS voltageCurrent annotate?:true
MINUS voltageCurrent balloon?:true
MINUS voltageCurrent displayType:DC
PLUS current annotate?:true
PLUS current balloon?:true
PLUS current displayType:DC
PLUS display mode:none
PLUS netName annotate?:true
PLUS netName balloon?:true
PLUS netName displayType:schematic
PLUS none annotate?:true
PLUS none balloon?:true
PLUS pinName annotate?:true
PLUS pinName balloon?:true
PLUS voltage annotate?:true
PLUS voltage balloon?:true
PLUS voltage displayType:DC
PLUS voltageCurrent annotate?:true
PLUS voltageCurrent balloon?:true
PLUS voltageCurrent displayType:DC
cdsParam:
1 dbLabel :true
1 display mode:opPoint
1 model annotate?:true
1 model balloon?:true
1 model label:none
1 none annotate?:true
1 none balloon?:true
1 opPoint annotate?:true
1 opPoint balloon?:true
1 opPoint displayType:DC
1 opPoint label:i
1 parameter annotate?:true
1 parameter balloon?:true
1 parameter displayType:t nil nil nil nil
1 parameter label:vdc
2 dbLabel :true
2 display mode:opPoint
2 model annotate?:true
2 model balloon?:true
2 model label:
2 none annotate?:true
2 none balloon?:true
2 opPoint annotate?:true
2 opPoint balloon?:true
2 opPoint displayType:DC
2 opPoint label:
2 parameter annotate?:true
2 parameter balloon?:true
2 parameter displayType:t nil nil nil nil
2 parameter label:acm
3 dbLabel :true
3 display mode:opPoint
3 model annotate?:true
3 model balloon?:true
3 model label:
3 none annotate?:true
3 none balloon?:true
3 opPoint annotate?:true
3 opPoint balloon?:true
3 opPoint displayType:DC
3 opPoint label:
3 parameter annotate?:true
3 parameter balloon?:true
3 parameter displayType:t nil nil nil nil
3 parameter label:acp

Instance:* * *
cdsName:
none  true true
cdsTerm:
 current annotate?:true
 current balloon?:true
 current displayType:DC
 display mode:none
 netName annotate?:true
 netName balloon?:true
 netName displayType:schematic
 none annotate?:true
 none balloon?:true
 pinName annotate?:true
 pinName balloon?:true
 voltage annotate?:true
 voltage balloon?:true
 voltage displayType:DC
 voltageCurrent annotate?:true
 voltageCurrent balloon?:true
 voltageCurrent displayType:DC
cdsParam:
 dbLabel :true
 display mode:opPoint
 model annotate?:true
 model balloon?:true
 model label:none
 none annotate?:true
 none balloon?:true
 none label:
 opPoint annotate?:true
 opPoint balloon?:true
 opPoint displayType:DC
 opPoint label:none
 parameter annotate?:true
 parameter balloon?:true
 parameter displayType:none
 parameter label:none

Instance:gpdk045 * *
cdsName:
instName schematic true true
cdsTerm:
 current annotate?:true
 current balloon?:true
 current displayType:DC
 display mode:none
 netName annotate?:true
 netName balloon?:true
 netName displayType:schematic
 none annotate?:true
 none balloon?:true
 pinName annotate?:true
 pinName balloon?:true
 voltage annotate?:true
 voltage balloon?:true
 voltage displayType:DC
 voltageCurrent annotate?:true
 voltageCurrent balloon?:true
 voltageCurrent displayType:DC
cdsParam:
 dbLabel :true
 display mode:opPoint
 model annotate?:true
 model balloon?:true
 model label:none
 none annotate?:true
 none balloon?:true
 none label:
 opPoint annotate?:true
 opPoint balloon?:true
 opPoint displayType:DC
 opPoint label:none
 parameter annotate?:true
 parameter balloon?:true
 parameter displayType:nil nil nil nil t
 parameter label:none
