import os
import numpy as np
import pandas as pd
from ngspice_interface.dut_testbench import DUT  # (inherits from NgspiceWrapper)
from circuit_env import CircuitEnv


def main():
    # === STEP 1: Define file paths ===
    # The DUT class inherits NgspiceWrapper, which needs a YAML path when initialized.
    project_path = os.getcwd()
    yaml_path = os.path.join(project_path, 'ngspice_interface', 'files', 'yaml_files', 'TwoStage.yaml')
    csv_path = os.path.join(project_path, 'reference_designs.csv')

    if not os.path.isfile(csv_path):
        print(f"❌ CSV file not found at {csv_path}")
        return

    df = pd.read_csv(csv_path)

    # Print info about the loaded data
    print(f"✅ Loaded {len(df)} reference designs from {csv_path}")
    print("Columns:", list(df.columns))
    print()



    # === STEP 2: Split into parameter and solution columns ===
    parameter_cols = ['mp1', 'wp1', 'lp1',
                      'mn1', 'wn1', 'ln1',
                      'mp3', 'wp3', 'lp3',
                      'mn3', 'wn3', 'ln3',
                      'mn4', 'wn4', 'ln4',
                      'mn5', 'wn5', 'ln5',
                      'cap', 'res']

    solution_cols = ['area', 'current', 'gain', 'noise', 'phm', 'slewRate', 'ugbw', 'reward']

    # === STEP 3: Choose one reference design (e.g., first row) ===
    # You can change this index to test different designs
    row_index = 0
    selected_row = df.iloc[row_index]

    # Extract parameter and solution data as dictionaries
    parameters = selected_row[parameter_cols].to_dict()
    solutions = selected_row[solution_cols].to_dict()


    # === STEP 4: Print what we got ===
    print(f"📘 Using reference design #{row_index}")
    print("Parameters:")
    for k, v in parameters.items():
        print(f"  {k}: {v}")

    print("\nReference solutions:")
    for k, v in solutions.items():
        print(f"  {k}: {v}")


    # === STEP 5: Create an instance of DUT ===
    # When you create an object, its __init__() method is automatically called.
    # Because DUT inherits from NgspiceWrapper, the NgspiceWrapper constructor is called first.
    dut = DUT(yaml_path)

    # Now you can access all attributes and methods from NgspiceWrapper
    print("Circuit name:", dut.circuit_name)
    print("Technology:", dut.technology)

    # === STEP 6: Change parameters dynamically ===
    # You can directly modify attributes like this:
    #dut.parameters['mp1'] = 20  # Change one parameter
    #dut.parameters.update({'res': 10e3, 'cap': 2e-12})  # Update multiple parameters

    # === STEP 7: Call inherited functions ===
    process = "TT"
    temp_pvt = 27
    vdd = 1.2

    # This function comes from NgspiceWrapper
    new_netlist_path = dut.create_new_netlist(
        parameters=parameters,  # use the updated parameters
        process=process,
        temp_pvt=temp_pvt,
        vdd=vdd
    )
    print(f"✅ New netlist created at: {new_netlist_path}")

    # === STEP 8: Run simulation ===
    info = dut.simulate(new_netlist_path)
    print("Simulation info (0 = OK):", info)

    # === STEP 9: Call child class (DUT) functions ===
    # Now call the DUT-specific method that processes results
    try:
        spec_dict = dut.measure_metrics()  # defined in DUT class
        spec_dict = convert_numpy_types(spec_dict)  # Clean up np types
        print("📊 Measured specifications:", spec_dict)
    except Exception as e:
        print("⚠️ Could not measure metrics (likely missing output files).")
        print("Error:", e)

    env = CircuitEnv(
        circuit_name='TwoStage', 
        run_id=0, 
        simulator='ngspice', 
        success_threshold=0.0
    )

    normalized_specs = env.normalize_specs(spec_dict)
    reward = env.reward_computation(normalized_specs)
    print(reward)



def convert_numpy_types(data):
    """
    Recursively converts numpy scalar types (np.float32, np.float64, np.int64, etc.)
    into native Python float/int types so they print cleanly or serialize to JSON.
    """
    if isinstance(data, dict):
        return {k: convert_numpy_types(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_numpy_types(v) for v in data]
    elif isinstance(data, np.generic):  # catches np.float64, np.int32, etc.
        return data.item()  # Convert to native Python scalar
    else:
        return data

# Standard Python entry point
if __name__ == "__main__":
    main()
