import time
import numpy as np
import os
import scipy.interpolate as interp
import scipy.optimize as sciopt
from scipy.optimize import differential_evolution
from .area_estimation import BPTM45nmAreaEstimator
from .ngspice_wrapper import NgspiceWrapper


class DUT(NgspiceWrapper):
    def measure_metrics(self):
        self.parse_outputs()
        spec_dict = {}
        # post process raw data
        area_estimator = BPTM45nmAreaEstimator(self.circuit_params, self.circuit_multipliers)
        spec_dict['area'] = area_estimator.find_area()
        spec_dict['current'] = self.current
        spec_dict['gain'] = self.find_dc_gain(self.vout_complex)
        spec_dict['noise'] = self.noise
        spec_dict['phm'] = self.find_phm(self.freq, self.vout_complex)
        spec_dict['slewRate'] = self.find_slew_rate(self.time, self.vout_tran, threshold_low=0.1, threshold_high=0.9, time_unit='us')
        spec_dict['ugbw'] = self.find_ugbw(self.freq, self.vout_complex)

        return spec_dict
    
    def parse_outputs(self):
        tran_fname = os.path.join(self.output_files_folder, 'tran_'+self.random_name+'.csv')
        ac_fname = os.path.join(self.output_files_folder, 'ac_'+self.random_name+'.csv')
        dc_fname = os.path.join(self.output_files_folder, 'dc_'+self.random_name+'.csv')
        noise_fname = os.path.join(self.output_files_folder, 'noise_'+self.random_name+'.csv')
        # add these file names in a list
        self.output_files = [tran_fname, ac_fname, dc_fname, noise_fname]
        for file in self.output_files:
            if not os.path.isfile(file):
                print(f"{file} doesn't exist")
        tran_raw_outputs = np.genfromtxt(tran_fname, skip_header=1)
        ac_raw_outputs = np.genfromtxt(ac_fname, skip_header=1)
        dc_raw_outputs = np.genfromtxt(dc_fname, skip_header=1)
        noise_raw_outputs = np.genfromtxt(noise_fname, skip_header=1)

        self.time = tran_raw_outputs[:, 0]
        self.vout_tran = tran_raw_outputs[:, 1]
        
        self.freq = ac_raw_outputs[:, 0]
        vout_real = ac_raw_outputs[:, 1]
        vout_imag = ac_raw_outputs[:, 2]
        self.vout_complex = vout_real + 1j*vout_imag
        
        self.current = - dc_raw_outputs[1]

        self.noise = noise_raw_outputs[0]
    
    def find_dc_gain(self, vout):
        """
        TODO: Implement the DC gain calculation
        
        Hint:
        Use numpy's abs() function to calculate the magnitude of the complex number at each point.
        """
        return np.abs(vout[0])
        
    def find_ugbw(self, freq, vout):
        """
        TODO: Implement the unity gain bandwidth (UGBW) calculation
        Hints:
        1. Calculate the magnitude of vout
        2. Find where the magnitude crosses 1 (unity gain)
        3. Use _get_best_crossing() to find the crossing point through interpolation
        4. What should you if no crossing is found? What situations can lead to this?
        """
        mag = np.abs(vout)

        if np.all(mag < 1):
            return 0
        elif np.all(mag > 1):
            return 0

        result = self._get_best_crossing(freq, mag, 1)

        if result[1]:
            return result[0]
        else:
            return 0
        
    
    def find_phm(self, freq, vout):
        """
        TODO: Implement the phase margin (PHM) calculation
        
        Hints:
        1. Calculate gain array and phase array from vout
        2. Find the unity gain frequency (UGBW)
        3. Interpolate to find the phase at UGBW (you can use interp.interp1d quadratic interpolation)
        4. Calculate phase margin (watch out for radians/degrees units and phase wrap around)
        5. Handle edge cases (e.g., when gain is always < 1) --> hint: you can think in RL terms; worst case reward ...
        """
        # --- 1. Compute magnitude and phase ---
        gain = np.abs(vout)
        phase = np.angle(vout, deg=True)  # phase in degrees
        phase = np.unwrap(np.deg2rad(phase))
        phase = np.rad2deg(phase)

        # --- 2. Find unity-gain frequency ---
        if np.all(gain < 1):
            return 0.0
        elif np.all(gain > 1):
            return 0.0

        idx = np.where(np.diff(np.sign(gain - 1)))[0]
        if len(idx) == 0:
            return 0.0

        i0 = idx[0]
        # make sure we have a small region to interpolate
        i_start = max(i0 - 2, 0)
        i_end = min(i0 + 3, len(freq))
        x_slice = freq[i_start:i_end]
        g_slice = gain[i_start:i_end]
        p_slice = phase[i_start:i_end]

        # --- 3. Interpolate to find phase at UGBW ---
        # Use quadratic interpolation (interp1d with kind='quadratic')
        f_phase = interp.interp1d(x_slice, p_slice, kind='quadratic', fill_value='extrapolate')

        # Find unity gain crossing using interpolation
        try:
            ugbw = self._get_best_crossing(x_slice, g_slice, 1.0)[0]
        except Exception:
            return 0.0

        phase_at_ugbw = float(f_phase(ugbw))

        # --- 4. Compute phase margin ---
        phm = 180.0 + phase_at_ugbw

        # --- 5. Handle edge cases ---
        if phm < 0 or phm > 180:
            return 0

        return phm

    
    def find_slew_rate(self, time, signal, threshold_low=0.1, threshold_high=0.9, time_unit='us'):

        # --- 1. Normalize thresholds based on signal range ---
        v_min, v_max = np.min(signal), np.max(signal)
        v_low = v_min + threshold_low * (v_max - v_min)
        v_high = v_min + threshold_high * (v_max - v_min)

        # --- 2. Find indices where signal crosses thresholds ---
        rising_edges = []
        above_low = signal > v_low
        above_high = signal > v_high

        # Find transitions (crossing up)
        for i in range(1, len(signal)):
            if not above_low[i-1] and above_low[i]:
                t_low = np.interp(v_low, [signal[i-1], signal[i]], [time[i-1], time[i]])
            if not above_high[i-1] and above_high[i]:
                t_high = np.interp(v_high, [signal[i-1], signal[i]], [time[i-1], time[i]])
                # If we previously had t_low, we can define a full rising edge
                if 't_low' in locals():
                    rising_edges.append((t_low, t_high))
                    del t_low  # reset for next edge

        if not rising_edges:
            return 0.0

        # --- 3. Compute slew rate for each edge ---
        slew_rates = []
        for t_low, t_high in rising_edges:
            dv = v_high - v_low
            dt = t_high - t_low
            if dt > 0:
                slew_rates.append(dv / dt)

        if not slew_rates:
            return 0.0

        avg_slew = np.mean(slew_rates)

        # --- 4. Convert to requested units (V/us by default) ---
        unit_scale = {
            's': 1.0,
            'ms': 1e-3,
            'us': 1e-6,
            'ns': 1e-9
        }
        if time_unit not in unit_scale:
            time_unit = 'us'

        slew_in_v_per_us = avg_slew * unit_scale[time_unit]
        return slew_in_v_per_us


    def _get_best_crossing(cls, xvec, yvec, val):
        interp_fun = interp.InterpolatedUnivariateSpline(xvec, yvec)

        def fzero(x):
            return interp_fun(x) - val

        xstart, xstop = xvec[0], xvec[-1]
        try:
            return sciopt.brentq(fzero, xstart, xstop), True
        except ValueError:
            return xstop, False