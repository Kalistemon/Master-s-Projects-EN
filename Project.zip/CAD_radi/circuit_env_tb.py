
from circuit_env import CircuitEnv
import numpy as np

# Reference solutions (as dictionaries)
reference_solutions = [
    {   # [0]
        "area": 9.77377845238095e-10,
        "current": 0.00050714721,
        "gain": 817.2324500046147,
        "noise": 0.039446578,
        "phm": 47.8961300512141,
        "slewRate": 3.935009521416636,
        "ugbw": 287939270.26242465,
        "reward_ref": -0.837118226303924,
    },
    {   # [1]
        "area": 1.8939731428571428e-09,
        "current": 6.3062567e-05,
        "gain": 89.637909012264,
        "noise": 0.0028557284,
        "phm": 52.440502130862455,
        "slewRate": 4.553232027350708,
        "ugbw": 4172793.7507562377,
        "reward_ref": -0.9551500268343924,
    },
    {   # [2]
        "area": 6.338428452380952e-10,
        "current": 5.8465647e-05,
        "gain": 151.1023500114643,
        "noise": 0.0023655671,
        "phm": 44.35755013884386,
        "slewRate": 6.205653666666708,
        "ugbw": 8581284.483782556,
        "reward_ref": -0.6505644390925518,
    },
    {   # [3]
        "area": 1.666403095238095e-09,
        "current": 0.00011065298,
        "gain": 188.3550900311509,
        "noise": 0.0030385342,
        "phm": 103.4538075980825,
        "slewRate": 6.219140771079,
        "ugbw": 14700608.521007696,
        "reward_ref": -0.4248731689770592,
    },
    {   # [4]
        "area": 1.3967347857142855e-09,
        "current": 7.4730222e-05,
        "gain": 54.21959600381273,
        "noise": 0.00101217,
        "phm": 96.87316631143796,
        "slewRate": 4.065660558268217,
        "ugbw": 4747450.820930383,
        "reward_ref": -1.1152736676397283,
    },
]

class DummySim:
    def __init__(self, *args, **kwargs):
        pass

    def simulate(self, params):
        # Will be replaced dynamically for each test
        return params


# Instantiate environment
env = CircuitEnv(circuit_name='TwoStage', simulator='ngspice')
env.simulation_engine = DummySim()  # replace real sim with dummy

# Choose which reference design to test
idx = 0
ref = reference_solutions[idx]

# Inject the reference specs directly into normalization and reward
norm_specs = env.normalize_specs(ref)
reward, hard_satisfied = env.reward_computation(norm_specs)

print(f"\n--- Reference {idx} ---")
print(f"Specs: {ref}")
print(f"Normalized specs: {norm_specs}")
print(f"Computed reward: {reward}")
print(f"Reference reward: {ref['reward_ref']}")
print(f"Hard constraints satisfied: {hard_satisfied}")


"""
action = np.random.uniform(-1, 1, size=env.n_actions)

print("Number of params:", env.n_actions)
print("Action shape:", action.shape)
print("Evaluated specs:", env.evaluate(action))
"""

