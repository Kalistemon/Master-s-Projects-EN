import gymnasium as gym
from gymnasium.spaces import Box
import numpy as np
import os
import yaml
import math
from ngspice_interface import DUT as DUT_NGSpice
from utils.saving import save_solutions_csv, save_best_solution_csv
from utils.plotting import plotLearning, plot_running_maximum, solutions2pareto 

class CircuitEnv(gym.Env):
    PER_LOW, PER_HIGH = -np.inf, +np.inf
    
    def __init__(self, config=None, circuit_name='TwoStage', run_id='rllib_baseline',
                 success_threshold=0.0, simulator='ngspice'):
        self.run_id = run_id
        self.max_steps_per_episode = 10
        self.env_steps = 0
        self.episode_steps = 0
        self.success_threshold = success_threshold
        self.circuit_name = circuit_name

        project_path = os.getcwd()
        yaml_directory = os.path.join(project_path, f"{simulator}_interface", 'files', 'yaml_files')
        circuit_yaml_path = os.path.join(yaml_directory, f'{circuit_name}.yaml')
        with open(circuit_yaml_path, 'r') as f:
            yaml_data = yaml.load(f, Loader=yaml.Loader)
        
        self.dict_params = yaml_data['params']
        self.dict_targets = yaml_data['targets']

        self.hard_constraints = yaml_data['hard_constraints']
        self.optimization_targets = yaml_data['optimization_targets']

        # number of input action components
        self.n_actions = len(self.dict_params)

        # number of output observation components
        self.obs_dim = len(self.dict_targets)

        self.param_ranges = {}
        for name, value in self.dict_params.items():
           self.param_ranges[name] = {'min': value[0], 'max': value[1], 'step': value[2]}
        
        self.simulation_engine = DUT_NGSpice(circuit_yaml_path)

        print(f"\n Initialized {circuit_name} with simulator {simulator} \n")

        # Action space & Observation space
        act_high = np.array([1 for _ in range(self.n_actions)])
        act_low = np.array([-1 for _ in range(self.n_actions)])
        self.action_space = Box(low=act_low, high=act_high)
        obs_high = np.array([CircuitEnv.PER_HIGH]*self.obs_dim, dtype=np.float32)
        obs_low = np.array([CircuitEnv.PER_LOW]*self.obs_dim, dtype=np.float32)
        self.observation_space = Box(low=obs_low, high=obs_high)

        # spec reward weights
        self.spec_weights = yaml_data['spec_weights']

        self.reward_history = []
        self.score_history = []

        self.counter = 0
        self.pvt_corner = {'process': 'TT', 'voltage': 1.2, 'temp': 27}
    
    def action_refine(self, action):
        """
        TODO: Implement a function that converts normalized actions to actual parameter values.
        
        This function should:
        1. Take a flattened numpy array of actions (values between -1 and 1)
        2. Convert each action value to the actual parameter value from self.parameter_ranges
        
        You have two options;
            1) Continuous mapping: convert the action directly to the parameter value based on the min-max values
            2) Discretize mapping: create a vector of possible values using the min-max-step from self.parameter_ranges, 
                                    then, map the action to an index of that vector and retreive the corresponding actual value.

        Args:
            action: numpy array of normalized values between -1 and 1
            
        Returns:
            dict: Dictionary mapping parameter names to their actual sizing values
                e.g., {'mp1': 13, 'wp1':2.0e-06, 'lp1':9.0e-08, ...}
        
        """

        # Ensure action is a flat numpy array

        action = np.array(action).flatten()
        assert len(action) == len(self.param_ranges), (f"Action length {len(action)} does not match number of parameters {len(self.param_ranges)}")

        refined_params = {}
        for i, (name, limits) in enumerate(self.param_ranges.items()):

            a = np.clip(action[i], -1, 1) # make sure action is within bounds
            param_min = limits['min']
            param_max = limits['max']

            # Continuous mapping: scale [-1, 1] → [min, max]
            value = param_min + (a + 1) * 0.5 * (param_max - param_min)
            refined_params[name] = value

        return convert_numpy_types(refined_params)
    

    def simulate(self, params):
        """
        TODO: Create/Simulate netlist with the given parameters and return the measured metrics.

        Args:
            params (dict): A dictionary containing the parameters for the simulation.

        Returns:
            dict: A dictionary containing the measured metrics from the simulation.
        """

        new_netlist_path = self.simulation_engine.create_new_netlist(
            parameters=params,
            process=self.pvt_corner['process'],
            temp_pvt=self.pvt_corner['temp'],
            vdd=self.pvt_corner['voltage']
        )
        self.simulation_engine.simulate(new_netlist_path)
        return self.simulation_engine.measure_metrics()

    
    def normalize_specs(self, spec_dict):
        """
        TODO: Normalize the specifications in `spec_dict` based on target specifications.

        This function normalizes the values in `spec_dict` by comparing them to the
        target specifications stored in `self.dict_targets`. The normalization is 
        performed using the formula:
            normalized_value = (spec_value - goal_value) / (spec_value + goal_value) 
        
        Args:
            spec_dict (dict): A dictionary containing the specifications to be normalized.
                              The keys should match those in `self.dict_targets`.
        
        Returns:
            dict: A dictionary containing the normalized specifications, with the same keys
                  as `spec_dict`.
        """
        normalized = {}

        for key, value in spec_dict.items():
            target = self.dict_targets.get(key, None)

            if target is None:
                continue # skip if no target defined

            if (value + target) == 0:
                norm_val = 0.0
            else:
                norm_val = (value - target) / (value + target)
            normalized[key] = norm_val
        return normalized
    
    def evaluate(self, action):
        self.param_values = self.action_refine(action)
        self.real_specs = self.simulate(self.param_values)
        self.cur_norm_specs = self.normalize_specs(self.real_specs)
    
    def reset(self, *, seed=None, options=None):
        """
        TODO: Reset the environment to an initial state and return the initial observation.

        Parameters:
            No mandatory input parameters (leave the input signature as is).
            seed (int, optional): A seed for the random number generator to ensure reproducibility.
            options (dict, optional): Additional options for the reset process.

        Returns:
            np.ndarray: The initial observation of the environment, which is the normalized current specifications.

        This method performs the following steps:
        1. Initializes the episode steps counter to zero.
        2. Generates a random action within the range [-1, 1] for each action parameter.
        3. Evaluates the environment with the generated random action.
        4. Resets the episode score to zero.
        5. Constructs the initial observation by returning the normalized current specifications.

        Note:
        - The observation is returned as a NumPy array of type float32.
        """
        super().reset(seed=seed) # handle Gym's seeding

        self.episode_steps = 0
        #self.env_steps = 0
        self.score = 0.0
        #self.reward_history.clear()

        # Generate random normalized actions between -1 and 1
        random_action = np.random.uniform(-1, 1, size=self.n_actions)

        # Evaluate this random circuit

        self.param_values = self.action_refine(random_action)
        self.real_specs = self.simulate(self.param_values)
        self.cur_norm_specs = self.normalize_specs(self.real_specs)

        # Convert normalized specs (dict) to np.array for RL observation
        obs = np.array(list(self.cur_norm_specs.values()), dtype=np.float32)

        return obs
    
    def step(self, action):
        """
        TODO: Perform a single step in the environment using the given action.

        This function should:
        1. Evaluate the given action.
        2. Compute the reward and check if the hard constraints are satisfied.
        3. Update the current observation.
        4. Append the reward to the reward history and update the score.
        5. Create output directories if they do not exist.
        6. If the goal state is reached, plot the running maximum reward.
        7. Increment the environment and episode step counters.
        8. Check if the maximum steps per episode have been reached, setting the done flag if true.
        9. Every 10 steps, update the score history, also plot the learning curve, and reset the score.
        10. Return the current observation, reward, done flag, and additional information.

        Args:
            action: The action to be taken in the environment. An array of values between -1 and 1.

        Returns:
            tuple: A tuple containing:
            - ob (np.ndarray): The current observation of the environment.
            - reward (float): The reward obtained from taking the action.
            - done (bool): A flag indicating whether the episode has ended.
            - info (dict): Additional information, including whether the goal state was reached.
        """
        #Evaluate the given action
        self.evaluate(action)

        #Compute reward and check hard constraints
        reward, hard_satisfied = self.reward_computation(self.cur_norm_specs)

        #Update the current observation
        ob = np.array(list(self.cur_norm_specs.values()), dtype=np.float32)

        #Append reward to history and update score
        self.reward_history.append(reward)
        self.counter += 1 # Counter for plotting / scoring
        self.score += reward

        #Create output directories if they don't exist
        # Ensure output folder exists

        output_dir = f"./output_figs/{self.run_id}"
        os.makedirs(output_dir, exist_ok=True)

        #If goal reached, plot running maximum reward

        plot_running_maximum(self.reward_history, self.run_id)
        #if hard_satisfied and reward > self.success_threshold:   
        if hard_satisfied:
            save_solutions_csv(self.run_id, self.env_steps, self.param_values, self.real_specs, reward)
            save_best_solution_csv(self.run_id,self.env_steps,self.param_values,self.real_specs,reward)
            solutions2pareto(f'./solutions/{self.run_id}.csv', self.run_id)

        #Increment environment and episode step counters
        self.episode_steps += 1
        self.env_steps += 1

        #Check if max steps per episode reached
        done = self.episode_steps >= self.max_steps_per_episode or hard_satisfied

        #Every 10 steps, update score history and plot learning curve
        if self.counter % 10 == 0:
            self.score_history.append(self.score)
            plotLearning(self.score_history, self.run_id)

        info = {
            'hard_constraints_satisfied': hard_satisfied,
            'episode_steps': self.episode_steps,
            'env_steps': self.env_steps,
            'param_values': self.param_values,
            'real_specs': self.real_specs
        }

        return ob, reward, done, info
    
    def reward_computation(self, norm_specs):
        """
        TODO: Compute the reward based on normalized specifications and hard constraints.

        Args:
            norm_specs (dict): A dictionary containing normalized specifications.

        Returns:
            tuple: A tuple containing:
            - reward (float): The computed reward value.
            - hard_satisfied (bool): A boolean indicating whether the hard constraints are satisfied.

        The function performs the following steps:
        1. Initialize the reward to 0.0 and hard_satisfied to False.
        2. Iterate over the hard constraints and adjust the reward based on the specifications.
        3. Check if all hard constraints are satisfied or the total reward passes the success threshold of 0.
            - If so, set hard_satisfied to True, add a bonus reward (+0.3), and adjust the reward based on optimization targets.
            - If not, add weighted reward components of the optimization targets.
        4. Return the computed reward and the hard_satisfied flag.
        """

        # ---- Step 1: Init ----
        reward = 0.0
        hard_satisfied = False
        h_sum = 0.0
        t_sum = 0.0

        # ---- Step 2: Check hard constraints ----
        constraints_passed = True  # local flag to track constraint status
        for spec in self.hard_constraints:
            if spec not in norm_specs or spec not in self.dict_targets:
                continue
            
            value = norm_specs[spec]

            # Direction depends on spec meaning
            if spec in ['gain', 'phm', 'slewRate', 'ugbw']:
                # These should be HIGHER than target
                h_sum += min(value, 0)
                if value < 0:
                    constraints_passed = False
            elif spec == 'noise':
                h_sum += -max(value, 0)
                # This should be LOWER than target
                if value > 0:
                    constraints_passed = False

        for spec in self.optimization_targets:
            if spec not in norm_specs or spec not in self.dict_targets:
                continue
            value = norm_specs[spec]
            t_sum += (- value)

        # If all passed → set hard_satisfied True
        if constraints_passed:
            hard_satisfied = True

        # ---- Step 3: Compute base reward ----
        if hard_satisfied:
            reward = 0.3 + t_sum
        else:
           reward = h_sum + 0.05 * t_sum

        return reward, hard_satisfied
    

def convert_numpy_types(data):
    """
    Recursively converts numpy scalar types (np.float32, np.float64, np.int64, etc.)
    into native Python float/int types so they print cleanly or serialize to JSON.
    """
    if isinstance(data, dict):
        return {k: convert_numpy_types(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [convert_numpy_types(v) for v in data]
    elif isinstance(data, np.generic):  # catches np.float64, np.int32, etc.
        return data.item()  # Convert to native Python scalar
    else:
        return data


if __name__ == '__main__':
    env = CircuitEnv(
        circuit_name='TwoStage', 
        run_id=0, 
        simulator='ngspice', 
        success_threshold=0.0
        )
    
    print(env.action_space)
    print(env.observation_space)

    ob = env.reset()
    print("Initial observation: ", ob)
    print("Initial parameters: ", env.param_values)
    print("Initial specs: ", env.real_specs)

    action = np.array([
        -0.5833333333333333, 0.4545454545454546, 0.0,
        -0.25, -0.8181818181818181, 0.0,
        -0.25, 0.09090909090909083, -0.5,
        -1.0, -0.4545454545454546, 0.0,
        -0.33333333333333337, 0.2727272727272727, 0.0,
        -0.5833333333333333, -0.6363636363636364, -0.5,
        -0.8585858585858586, 0.9191919191919192
        ])

    #action = np.random.uniform(-1, 1, [env.n_actions])
    ob, reward, done, info = env.step(action)
    print("Next parameters: ", env.param_values)
    print("Next observation: ", ob)
    print("Next specs: ", env.real_specs)
    print("Reward: ", reward)
    print("Done: ", done)
