import pandas as pd
import numpy as np
import os
import csv

def save_solutions_csv(run_id, simulation_step, circuit_params, specs, reward):
    # Define the CSV file name based on the run_id to keep it unique
    csv_file_name = f'./solutions/{run_id}.csv'
    # Define the header for the CSV file
    header = ['Simulation step', 'Specs', 'Circuit Params', 'Reward']
    # Prepare the data to be written
    data = [simulation_step, str(specs), str(circuit_params), reward]
    
    try:
        # Check if the CSV file already exists
        file_exists = os.path.isfile(csv_file_name)
        with open(csv_file_name, 'a', newline='') as csvfile:
            writer = csv.writer(csvfile)
            # If the file does not exist, write the header first
            if not file_exists:
                writer.writerow(header)
            # Write the data
            writer.writerow(data)
            # write an empty row after each write operation
            writer.writerow([])
    except Exception as e:
        print(f"Error saving solution to CSV: {e}")
    
    return csv_file_name


def save_best_solution_csv(run_id, simulation_step, circuit_params, specs, reward):
    """
    Save the solution to ./solutions/{run_id}_best.csv only if reward is strictly larger
    than any reward already in that file. The first valid solution is always saved.
    Returns the path of the best-file.
    """
    os.makedirs('./solutions', exist_ok=True)
    csv_file_name = f'./solutions/{run_id}_best.csv'
    header = ['Simulation step', 'Specs', 'Circuit Params', 'Reward']

    # normalize reward to a Python float (handles numpy.float64 etc)
    try:
        reward_value = float(reward)
    except Exception:
        # If reward can't be parsed, reject it
        print(f"⚠️  Could not parse reward ({reward}), skipping save to best CSV.")
        return csv_file_name

    # If file doesn't exist -> create and write first solution
    if not os.path.isfile(csv_file_name):
        try:
            with open(csv_file_name, 'w', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(header)
                writer.writerow([simulation_step, str(specs), str(circuit_params), reward_value])
            print(f"✅ First best solution saved (reward = {reward_value:.6f}) to {csv_file_name}")
        except Exception as e:
            print(f"Error creating best CSV file: {e}")
        return csv_file_name

    # If file exists -> read existing rewards robustly and decide
    best_reward_so_far = -np.inf
    try:
        # Use pandas for robust reading and to skip blank rows
        df = pd.read_csv(csv_file_name, dtype=str, keep_default_na=False)
        if not df.empty and 'Reward' in df.columns:
            # Try convert Reward column to floats; ignore non-convertible values
            rewards = []
            for v in df['Reward'].tolist():
                try:
                    rewards.append(float(v))
                except Exception:
                    continue
            if rewards:
                best_reward_so_far = max(rewards)
    except Exception as e:
        print(f"Warning: could not read existing best CSV reliably: {e}. Proceeding with best_reward_so_far = -inf")

    # Compare and append only if strictly improved
    if reward_value > best_reward_so_far:
        try:
            with open(csv_file_name, 'a', newline='') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow([simulation_step, str(specs), str(circuit_params), reward_value])
        except Exception as e:
            print(f"Error appending to best CSV: {e}")

    return csv_file_name
