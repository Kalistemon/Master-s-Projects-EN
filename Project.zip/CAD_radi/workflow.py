from google import genai
from google.genai import types
from dotenv import load_dotenv
import numpy as np
import os
import json
import re
import csv
import ast
import torch
from circuit_env import CircuitEnv
# from td3_runner import main as run_td3_training
from td3_runner import readParser
from td3 import TD3, ReplayBuffer
import time

env_path = "./local.env"
load_dotenv(dotenv_path=env_path)
client = genai.Client()

class IterativeWorkflow:
    """
    Iterative workflow that alternates between TD3 training and Master optimization
    """
    
    def __init__(self, circuit_name='TwoStage', total_cycles=10, td3_steps_per_cycle=200):
        self.circuit_name = circuit_name
        self.total_cycles = total_cycles
        self.td3_steps_per_cycle = td3_steps_per_cycle
        self.run_id = f"iterative_workflow_{int(time.time())}"
        
        print(f"🔄 Initializing Iterative Workflow")
        print(f"   Total cycles: {total_cycles}")
        print(f"   TD3 steps per cycle: {td3_steps_per_cycle}")
        print(f"   Run ID: {self.run_id}")
    
    def run_cycle(self, cycle_num):
        """Run one cycle of TD3 training followed by Master optimization"""
        print(f"\n{'='*50}")
        print(f"🔄 CYCLE {cycle_num}/{self.total_cycles}")
        print(f"{'='*50}")
        
        # Step 1: Run TD3 training
        print("🤖 Running TD3 Training...")
        self.run_td3_training(cycle_num)
        
        # Step 2: Check for Pareto solutions
        print("📊 Checking for Pareto solutions...")
        solutions = self.load_pareto_solutions(top_k=3)
        
        if solutions:
            print(f"✅ Found {len(solutions)} Pareto solutions for Master optimization")
            # Step 3: Run Master optimization
            best_solution = self.run_master_optimization(solutions, cycle_num)
            return best_solution
        else:
            print("❌ No Pareto solutions found yet, continuing with TD3 training")
            return None
    
    def run_td3_training(self, cycle_num):
        """Run TD3 training for specified number of steps"""
        # Modify TD3 arguments for this cycle
        args = self.get_td3_args(cycle_num)
        
        # Set random seed
        torch.manual_seed(args.seed)
        np.random.seed(args.seed)
        
        # Run TD3 training
        env = CircuitEnv(run_id=self.run_id)
        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.shape[0]
        agent = TD3(state_dim, env.action_space, args)
        env_pool = ReplayBuffer(state_dim, action_dim, max_size=args.replay_size)
        
        # Run training for this cycle
        total_steps = self.warmup_exploration(args, env, env_pool, agent)
        while total_steps < self.td3_steps_per_cycle:
            obs = env.reset()
            done = False
            while not done and total_steps < self.td3_steps_per_cycle:
                action = agent.select_action(obs)
                next_state, reward, done, info = env.step(action)
                env_pool.push(obs, action, reward, next_state, done)
                obs = next_state
                self.train_policy(args, env_pool, agent, total_steps)
                total_steps += 1
                
                # Clean up periodically
                if total_steps % 100 == 0:
                    os.system('./clean.sh')
        
        print(f"✅ TD3 training completed: {total_steps} steps")
    
    def get_td3_args(self, cycle_num):
        """Get TD3 arguments for this cycle"""
        args = readParser()
        args.T = self.td3_steps_per_cycle
        args.run_id = self.run_id
        # You can modify other args here based on cycle number if needed
        return args
    
    def warmup_exploration(self, args, env, env_pool, agent):
        """Warmup exploration phase"""
        step_counter = 0
        while step_counter < args.w:
            obs = env.reset()
            done = False
            while not done and step_counter < args.w:
                action = env.action_space.sample()
                next_state, reward, done, info = env.step(action)
                env_pool.push(obs, action, reward, next_state, done)
                obs = next_state
                step_counter += 1
        return step_counter
    
    def train_policy(self, args, env_pool, agent, total_steps):
        """Train policy for one step"""
        if env_pool.size > args.batch_size:
            state, action, reward, next_state, done = env_pool.sample(args.batch_size)
            batch = (state, action, reward, next_state, done)
            agent.update_parameters(memory_batch=batch, update=total_steps)
    
    def load_pareto_solutions(self, top_k=3):
        """Load Pareto solutions from current run"""
        csv_file = f"./solutions/{self.run_id}.csv"
        
        if not os.path.exists(csv_file):
            return []
        
        solutions = []
        with open(csv_file, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    # Skip empty rows
                    if not row['Simulation step'] or not row['Specs']:
                        continue
                        
                    reward_val = float(row['Reward'])
                    
                    # Parse the specs dictionary - handle np.float64
                    specs_str = row['Specs'].replace('np.float64(', '').replace(')', '')
                    specs_dict = ast.literal_eval(specs_str)
                    
                    # Parse circuit parameters
                    params_dict = ast.literal_eval(row['Circuit Params'])
                    
                    solutions.append({
                        'params': params_dict,
                        'specs': specs_dict,
                        'reward': reward_val
                    })
                    
                except (ValueError, SyntaxError, KeyError, Exception) as e:
                    continue
        
        # Remove duplicates and take top K by reward
        unique_solutions = []
        seen_params = set()
        
        for sol in solutions:
            param_hash = tuple(sorted((k, round(v, 10)) for k, v in sol['params'].items()))
            if param_hash not in seen_params:
                seen_params.add(param_hash)
                unique_solutions.append(sol)
        
        # Sort by reward (highest first) and take top K
        unique_solutions.sort(key=lambda x: x['reward'], reverse=True)
        return unique_solutions[:top_k]
    
    def run_master_optimization(self, solutions, cycle_num):
        """Run Master optimization on given solutions"""
        print("👑 Running Master Optimization...")
        
        master = MasterAgent(self.circuit_name)
        best_solution = None
        best_improvement = 0.0
        
        # Optimize each solution
        for i, solution in enumerate(solutions):
            print(f"  Optimizing Solution {i+1} (reward: {solution['reward']:.3f})")
            
            optimized_solution, improvement = master.optimize_solution(solution)
            
            if improvement > 0:
                print(f"    Improvement: +{improvement:.3f}")
            else:
                print(f"    No improvement: {improvement:+.3f}")
            
            # Track best solution
            if best_solution is None or optimized_solution['reward'] > best_solution['reward']:
                best_solution = optimized_solution
                best_improvement = improvement
        
        # Save results
        if best_solution:
            self.save_master_results(best_solution, cycle_num, best_improvement)
            return best_solution
        
        return None
    
    def save_master_results(self, solution, cycle_num, improvement):
        """Save Master optimization results"""
        try:
            from utils.saving import save_solutions_csv
            save_solutions_csv(
                f"{self.run_id}_master", 
                cycle_num,
                solution['params'],
                solution['specs'],
                solution['reward']
            )
            print(f"💾 Master results saved for cycle {cycle_num}")
        except Exception as e:
            print(f"Note: Could not save Master results: {e}")
    
    def run(self):
        """Run the complete iterative workflow"""
        print("🚀 Starting Iterative Workflow")
        
        best_overall_solution = None
        best_overall_reward = -float('inf')
        
        for cycle in range(1, self.total_cycles + 1):
            cycle_solution = self.run_cycle(cycle)
            
            # Track best solution across all cycles
            if cycle_solution and cycle_solution['reward'] > best_overall_reward:
                best_overall_solution = cycle_solution
                best_overall_reward = cycle_solution['reward']
                print(f"🏆 New overall best solution found: {best_overall_reward:.3f}")
        
        # Final results
        print(f"\n{'='*50}")
        print("🎉 ITERATIVE WORKFLOW COMPLETED")
        print(f"{'='*50}")
        
        if best_overall_solution:
            print(f"🏆 BEST OVERALL SOLUTION")
            print(f"Final reward: {best_overall_solution['reward']:.3f}")
            
            # Print specification comparison
            master = MasterAgent(self.circuit_name)
            self.print_spec_comparison(best_overall_solution['specs'], master.targets)
            
            # Save final best solution
            try:
                from utils.saving import save_solutions_csv
                save_solutions_csv(
                    f"{self.run_id}_final_best", 
                    999,
                    best_overall_solution['params'],
                    best_overall_solution['specs'],
                    best_overall_solution['reward']
                )
                print(f"💾 Final best solution saved")
            except Exception as e:
                print(f"Note: Could not save final solution: {e}")
        else:
            print("❌ No valid solution found in any cycle")
        
        return best_overall_solution
    
    def print_spec_comparison(self, specs: dict, targets: dict):
        """Print specification comparison between achieved and target values"""
        print("\n📊 Final Specification Comparison:")
        print("Specification | Achieved | Target | Status")
        print("--------------|----------|--------|--------")
        
        for spec, value in specs.items():
            target = targets.get(spec)
            if target is not None:
                if spec in ['gain', 'phm', 'slewRate', 'ugbw']:
                    status = "✓" if value >= target else "✗"
                else:  # noise, area, current
                    status = "✓" if value <= target else "✗"
                print(f"{spec:13} | {value:8.3f} | {target:6} | {status}")


class MasterAgent:
    """
    Master: Makes intelligent adjustments to improve solutions from Pareto front
    """
    
    def __init__(self, circuit_name='TwoStage'):
        self.circuit_name = circuit_name
        self.env = CircuitEnv(circuit_name=circuit_name, run_id="master_optimizer")
        self.targets = self.env.dict_targets
        
        # Tool declaration for circuit optimization
        self.tools = types.Tool(
            function_declarations=[{
                "name": "circuit_optimizer",
                "description": "Optimize circuit parameters to improve reward",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "parameter_adjustments": {
                            "type": "object",
                            "description": "Dictionary of parameter adjustments with percentage changes"
                        },
                        "reasoning": {
                            "type": "string", 
                            "description": "Explanation of adjustments"
                        }
                    },
                    "required": ["parameter_adjustments", "reasoning"]
                }
            }]
        )
        
        self.config = types.GenerateContentConfig(
            tools=[self.tools],
            temperature=0.1,
            max_output_tokens=1000
        )
        
        print("👑 Master Agent initialized")

    def optimize_solution(self, solution: dict, max_iterations: int = 3):
        """
        Optimize a single solution using LLM-guided adjustments
        Returns: (optimized_solution, improvement)
        """
        current_solution = solution.copy()
        best_solution = solution.copy()
        improvement = 0.0
        
        for iteration in range(max_iterations):
            llm_suggestion = self._ask_master_for_optimization(current_solution, iteration + 1)
            
            if not llm_suggestion:
                break
                
            new_params = self._apply_parameter_adjustments(
                current_solution['params'], 
                llm_suggestion['parameter_adjustments']
            )
            
            try:
                new_specs = self.env.simulate(new_params)
                norm_specs = self.env.normalize_specs(new_specs)
                new_reward, hard_satisfied = self.env.reward_computation(norm_specs)
                
                if new_reward > current_solution['reward'] and hard_satisfied:
                    current_solution = {
                        'params': new_params,
                        'specs': new_specs,
                        'reward': new_reward
                    }
                    
                    if new_reward > best_solution['reward']:
                        best_solution = current_solution.copy()
                        improvement = new_reward - solution['reward']
                        print(f"    Improvement: +{improvement:.3f}")
            except Exception as e:
                print(f"    Simulation error: {e}")
                continue
        
        return best_solution, improvement
    
    def _ask_master_for_optimization(self, solution: dict, iteration: int):
        """Use LLM to get optimization suggestions"""
        prompt = f"""
        You are an expert analog circuit designer. Optimize this circuit design.

        Current reward: {solution['reward']:.3f}
        Parameters: {json.dumps(self._format_parameters(solution['params']), indent=2)}
        Specifications: {json.dumps(self._format_specs(solution['specs']), indent=2)}
        Targets: {json.dumps(self.targets, indent=2)}

        Analyze which specifications are over/under target and suggest 2-3 parameter adjustments (1-20% changes).
        Focus on trading over-achieved specs for better overall reward.
        """

        try:
            response = client.models.generate_content(
                model="gemini-2.0-flash", 
                contents=prompt,
                config=self.config
            )
            
            # Extract function call from response
            for part in response.candidates[0].content.parts:
                if hasattr(part, 'function_call') and part.function_call:
                    return {
                        'parameter_adjustments': part.function_call.args['parameter_adjustments'],
                        'reasoning': part.function_call.args['reasoning']
                    }
            
            # Fallback: parse text response
            return self._parse_text_response_for_adjustments(response.text)
            
        except Exception as e:
            print(f"    LLM API error: {e}")
            return None
    
    def _parse_text_response_for_adjustments(self, text_response: str):
        """Fallback: Try to parse LLM text response for parameter adjustments"""
        adjustments = {}
        patterns = [
            r'(increase|decrease)\s+(\w+)\s+by\s+([\d.]+)%',
            r'(\w+)\s*:\s*([+-]?[\d.]+)%',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text_response.lower())
            for match in matches:
                if len(match) == 3:
                    direction, param, percentage = match
                    change = float(percentage) if direction == 'increase' else -float(percentage)
                else:
                    param, percentage = match
                    change = float(percentage)
                
                if param in self._get_parameter_names():
                    adjustments[param] = change
        
        if adjustments:
            return {
                'parameter_adjustments': adjustments,
                'reasoning': 'Parsed from text response'
            }
        return None
    
    def _get_parameter_names(self):
        return ['mp1', 'wp1', 'lp1', 'mn1', 'wn1', 'ln1', 'mp3', 'wp3', 'lp3', 
                'mn3', 'wn3', 'ln3', 'mn4', 'wn4', 'ln4', 'mn5', 'wn5', 'ln5', 
                'cap', 'res']
    
    def _format_specs(self, specs: dict) -> dict:
        formatted = {}
        for key, value in specs.items():
            if isinstance(value, float):
                if key == 'area': formatted[key] = f"{value:.2e} m²"
                elif key == 'current': formatted[key] = f"{value:.2e} A" 
                elif key == 'gain': formatted[key] = f"{value:.1f} dB"
                elif key == 'phm': formatted[key] = f"{value:.1f}°"
                elif key == 'slewRate': formatted[key] = f"{value:.1f} V/µs"
                elif key == 'ugbw': formatted[key] = f"{value:.2e} Hz"
                else: formatted[key] = f"{value:.4f}"
            else:
                formatted[key] = value
        return formatted
    
    def _apply_parameter_adjustments(self, current_params: dict, adjustments: dict) -> dict:
        new_params = current_params.copy()
        for param_name, adjustment in adjustments.items():
            if param_name in new_params:
                try:
                    percentage_change = float(adjustment)
                    change_factor = 1 + (percentage_change / 100.0)
                    new_params[param_name] = new_params[param_name] * change_factor
                    new_params[param_name] = max(new_params[param_name], 1e-12)
                except (ValueError, TypeError):
                    continue
        return new_params
    
    def _format_parameters(self, params: dict) -> dict:
        formatted = {}
        for key, value in params.items():
            if isinstance(value, float):
                formatted[key] = f"{value:.2e}"
            else:
                formatted[key] = value
        return formatted


def main():
    """Main function to run the iterative workflow"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Iterative TD3 + Master Workflow')
    parser.add_argument('--cycles', type=int, default=10, help='Number of iterative cycles')
    parser.add_argument('--steps_per_cycle', type=int, default=200, help='TD3 steps per cycle')
    parser.add_argument('--circuit', type=str, default='TwoStage', help='Circuit name')
    
    args = parser.parse_args()
    
    # Run iterative workflow
    workflow = IterativeWorkflow(
        circuit_name=args.circuit,
        total_cycles=args.cycles,
        td3_steps_per_cycle=args.steps_per_cycle
    )
    
    best_solution = workflow.run()
    
    if best_solution:
        print(f"\n🎉 Workflow completed successfully!")
        print(f"Best solution reward: {best_solution['reward']:.3f}")
    else:
        print(f"\n⚠️ Workflow completed but no optimal solution found")


if __name__ == "__main__":
    main()